# IdeaSpark.ai – MVP Homepage

This is the improved MVP of **IdeaSpark.ai**, a web platform designed to help users explore innovative ideas using Zero to One thinking.

## 🌐 Features

- Categorized Google-style results: Clearly Exists, Somewhat Exists, Doesn’t Exist Yet
- Zero to One Analyzer toggle
- Opportunity Heatmap
- Blind Spot + Monopoly Potential Alerts (placeholder logic)

## 📦 Files

- `index.html`: Main HTML file with Tailwind CSS
- `README.md`: Instructions for deployment

## 🚀 Deployment Options

### Option 1: Deploy via Netlify (No code required)
1. Go to [https://app.netlify.com/drop](https://app.netlify.com/drop)
2. Drag and drop the entire folder
3. Done! You’ll get a live URL

### Option 2: Deploy via GitHub + Vercel (More flexible)
1. Push this folder to a new GitHub repository
2. Go to [https://vercel.com](https://vercel.com) and connect your GitHub
3. Import the project → click “Deploy”
4. Done! You’ll get a `.vercel.app` live site

## 🧠 What's Next

This version is static. For a dynamic MVP:
- Add GPT-4 or OpenAI API for idea analysis
- Integrate Google Programmable Search API for live result fetching
- Build backend logic in Node.js or Python

