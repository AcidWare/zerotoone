export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Only POST allowed' });
  }

  const { idea, mode } = req.body;

  // Simulate categorized search results
  const mockResponse = {
    zeroToOneScore: 82,
    categories: {
      clearlyExists: [
        { title: "Fitbit Stress Monitoring", description: "Manages stress tracking in wearables." },
        { title: "Garmin Body Battery", description: "Tracks energy and stress throughout the day." }
      ],
      somewhatExists: [
        { title: "Empatica E4", description: "Used in research for physiological signals." },
        { title: "Basic stress apps", description: "Not specialized for early burnout detection." }
      ],
      doesntExistYet: [
        { title: "No comprehensive burnout detection wearable", description: "Blue Ocean Potential" }
      ]
    },
    insights: {
      blindSpot: "Consider targeting remote tech workers or B2B market.",
      heatmapTags: ["Mental Health", "Wearables", "Corporate Wellness"]
    }
  };

  res.status(200).json(mockResponse);
}
